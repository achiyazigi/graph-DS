in this project i implemented an undirectional unweighted graph data stracture.
it has the ability to add/remove nodes, add/remove edges and more.
forthermore, i implemented a graph algorithms class which, after initialization, can compute shortest path, shortest path distance,
and check if the graph is connected. for more information and bugs reports, contact me at:
achiyazigi@gmail.com